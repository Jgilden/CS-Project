package com.example.springtemplate.daos;

import com.example.springtemplate.models.Recipe;
import com.example.springtemplate.models.User;
import com.example.springtemplate.repositories.RecipeRepository;
import com.example.springtemplate.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class RecipeOrmDao {
    @Autowired
    RecipeRepository recipeRepository;

    @Autowired
    UserRepository userRepository;

    @PostMapping("/api/recipes")
    public Recipe createRecipe(@RequestBody Recipe recipe) {
        return recipeRepository.save(recipe);
    }

    @GetMapping("/api/recipes")
    public List<Recipe> findAllRecipes() {
        return recipeRepository.findAllRecipes();
    }

    @GetMapping("/api/recipes/{recipeId}")
    public Recipe findRecipeById(
            @PathVariable("recipeId") Integer id) {
        return recipeRepository.findRecipeById(id);
    }

    @PutMapping("/api/recipes/{recipeId}")
    public Recipe updateRecipe(
            @PathVariable("recipeId") Integer id,
            @RequestBody Recipe recipeUpdates) {
        Recipe recipe = recipeRepository.findRecipeById(id);
        recipe.setRecipeName(recipeUpdates.getRecipeName());
        recipe.setPrepTime(recipeUpdates.getPrepTime());
        recipe.setCookTime(recipeUpdates.getCookTime());
        recipe.setServingSize(recipeUpdates.getServingSize());
        recipe.setDietaryRestriction(recipeUpdates.getDietaryRestriction());
        recipe.setInstructions(recipeUpdates.getInstructions());
        recipe.setRecipeIngredients(recipeUpdates.getRecipeIngredients());
        return recipeRepository.save(recipe);
    }

    @DeleteMapping("/api/recipes/{recipeId}")
    public void deleteRecipe(
            @PathVariable("recipeId") Integer id) {
        recipeRepository.deleteById(id);
    }

    @GetMapping("/api/users/{userId}/recipes")
    public List<Recipe> findRecipeByUserId(
            @PathVariable("userId") int userId){
        User user = userRepository.findUserById(userId);
        return user.getRecipes();
    }

    @PostMapping("/api/users/{userId}/createRecipes")
    public void createdRecipeForUser(
            @PathVariable("userId") int userId,
            @PathVariable("recipeId") int recipeId){
        User user = userRepository.findUserById(userId);
        Recipe recipe = recipeRepository.findRecipeById(recipeId);
        recipe.setUser(user);
        recipeRepository.save(recipe);
    }
}