package com.example.springtemplate.daos;

import com.example.springtemplate.models.Recipe;
import com.example.springtemplate.models.RecipeIngredient;
import com.example.springtemplate.models.RecipeIngredientId;
import com.example.springtemplate.models.User;
import com.example.springtemplate.repositories.IngredientRepository;
import com.example.springtemplate.repositories.RecipeIngredientRepository;
import com.example.springtemplate.repositories.RecipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class RecipeIngredientOrmDao {
    @Autowired
    RecipeRepository recipeRepository;

    @Autowired
    IngredientRepository ingredientRepository;

    @Autowired
    RecipeIngredientRepository recipeIngredientRepository;

    @PostMapping("/api/recipeIngredients")
    public RecipeIngredient createRecipeIngredient(@RequestBody RecipeIngredient recipeIngredient) {
        return recipeIngredientRepository.save(recipeIngredient);
    }

    @GetMapping("/api/recipeIngredients")
    public List<RecipeIngredient> findAllRecipeIngredients() {
        return recipeIngredientRepository.findAllRecipeIngredients();
    }

    @GetMapping("/api/recipeIngredients/{recipeIngredientId}")
    public RecipeIngredient findRecipeIngredientById(
            @PathVariable("recipeIngredientId") Integer id) {
        return recipeIngredientRepository.findRecipeIngredientById(id);
    }

    @PutMapping("/api/recipeIngredients/{recipeIngredientId}")
    public RecipeIngredient updateRecipeIngredient(
            @PathVariable("recipeIngredientId") Integer id,
            @RequestBody RecipeIngredient recipeIngredientUpdates) {
        RecipeIngredient recipeIngredient = recipeIngredientRepository.findRecipeIngredientById(id);
        recipeIngredient.setUnit(recipeIngredientUpdates.getUnit());
        recipeIngredient.setQuantity(recipeIngredientUpdates.getQuantity());
        recipeIngredient.setPrepMethod(recipeIngredientUpdates.getPrepMethod());
        recipeIngredient.setRecipe(recipeIngredientUpdates.getRecipe());
        recipeIngredient.setIngredient(recipeIngredientUpdates.getIngredient());
        return recipeIngredientRepository.save(recipeIngredient);
    }

    @GetMapping("/api/recipes/{recipeId}/recipeIngredients")
    public List<RecipeIngredient> findRecipeIngredientByRecipeIngredientId(
            @PathVariable("recipeId") int recipeId){
        Recipe recipe = recipeRepository.findRecipeById(recipeId);
        return recipe.getRecipeIngredients();
    }

    @PostMapping("/api/recipes/{recipeId}/RecipeIngredients")
    public void createRecipeIngredientForRecipe(
            @PathVariable("recipeId") int recipeId,
            @PathVariable("recipeIngredientId") int recipeIngredientId){
        Recipe recipe = recipeRepository.findRecipeById(recipeId);
        RecipeIngredient recipeIngredient = recipeIngredientRepository.findRecipeIngredientById(recipeIngredientId);
        recipeIngredient.setRecipe(recipe);
        recipeIngredientRepository.save(recipeIngredient);
    }

//    @PutMapping("/api/add/{ingredientId}/in/{recipeId}")
//    public RecipeIngredient IngredientInRecipe(
//            @PathVariable("recipeId") Integer recipeId,
//            @PathVariable("ingredientId") Integer ingredientId){
//        RecipeIngredientId recipeIngredientId = null;
//        RecipeIngredient recipeIngredient = new RecipeIngredient();
//        recipeIngredientId.setRecipeId(recipeId);
//        recipeIngredientId.setIngredientId(ingredientId);
//        recipeIngredientRepository.save(recipeIngredient);
//        return recipeIngredient;
//    }
//
//    @DeleteMapping("/api/delete/{ingredientId}/from/{recipeId}")
//    public void deleteIngredientFromRecipe(
//            @PathVariable("recipeId") Integer recipeId,
//            @PathVariable("ingredientId") Integer ingredientId){
//        RecipeIngredientId recipeIngredientId = new RecipeIngredientId();
//        recipeIngredientId.setRecipeId(recipeId);
//        recipeIngredientId.setIngredientId(ingredientId);
//        recipeIngredientRepository.deleteById(recipeIngredientId);
//    }
}
