import RecipeIngredientList from "./recipeIngredient-list";
import RecipeIngredientFormEditor from "./recipeIngredient-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM; 
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/ingredients", "/"]} exact={true}>
                    <RecipeIngredientList/>
                </Route>
                <Route path="/ingredients/:id" exact={true}>
                    <RecipeIngredientFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
