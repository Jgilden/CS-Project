// const {Link, useHistory} = window.ReactRouterDOM;
//
// import ingredientService from "./recipeIngredient-service"
// const { useState, useEffect } = React;
//
// const RecipeIngredientList = () => {
//     const history = useHistory()
//     const [ingredients, setIngredients] = useState([])
//     useEffect(() => {
//         findAllIngredients()
//     }, [])
//     const findAllIngredients = () =>
//         ingredientService.findAllIngredients()
//             .then(ingredients => setIngredients(ingredients))
//     return(
//         <div>
//             <h2>Ingredient List</h2>
//             <button onClick={() => history.push("/ingredients/new")}>
//                 Add Ingredient
//             </button>
//             <ul className="list-group">
//                 {
//                     ingredients.map(ingredient =>
//                         <li key={ingredient.ingredientId}>
//                             <Link to={`/ingredients/${ingredient.ingredientId}`}>
//                                 {ingredient.ingredient}
//                             </Link>
//                         </li>)
//                 }
//             </ul>
//         </div>
//     )
// }
//
// export default RecipeIngredientList;


const {Link, useHistory} = window.ReactRouterDOM;

import recipeIngredientService from "./recipeIngredient-service"
import recipeService, {findRecipeById} from "../recipes/recipe-service"
const { useState, useEffect } = React;
const {useParams} = window.ReactRouterDOM;

const RecipeIngredientList = () => {
    const [recipeIngredients, setRecipeIngredients] = useState([])
    const[newRecipeIngredient, setNewRecipeIngredient] = useState([])
    const {recipeId} = useParams()
    useEffect(() => {findRecipeIngredientByRecipeId(recipeId)}, [])
    const createRecipeIngredientForRecipe = (recipeIngredient) =>
        recipeIngredientService.createRecipeIngredientForRecipe(recipeId, recipeIngredient)
            .then(recipeIngredient => {
                setNewRecipeIngredient({recipeIngredient:''})
                setRecipeIngredients(recipeIngredients => ([...recipeIngredients, recipeIngredient]))
            })

    const updateRecipeIngredient = (id, newRecipeIngredient) =>
        recipeIngredientService.updateRecipeIngredient(id, newRecipeIngredient)
            .then(recipeIngredients => setRecipeIngredients(recipeIngredients =>
                (recipeIngredients.map(recipeIngredient => recipeIngredient.id === id ? newRecipeIngredient : recipeIngredient))))
    const findRecipeIngredientByRecipeId = (id) =>
        recipeIngredientService.findRecipeIngredientByRecipeId(recipeId)
            .then(recipes => setRecipeIngredients(recipeIngredients))
    const deleteRecipeIngredient = (id) =>
        recipeIngredientService.deleteRecipeIngredient(id)
            .then(recipeIngredients => setRecipeIngredients(recipeIngredients => recipeIngredients.filter(recipeIngredient => recipeIngredient.id !== id)))
    return(
        <div>
            <h2>Recipe Ingredient List</h2>
            <button onClick={() => history.push("/recipeIngredients/new")}>
                Add Recipe
            </button>
            <ul className="list-group">
                {
                    recipeIngredients.map(recipeIngredient =>
                        <li key={recipeIngredient.id}>
                            <Link to={`/users/${recipeId}/recipeIngredients/${recipeIngredient.id}`}>
                                {recipeIngredient.id}
                            </Link>
                        </li>)
                }
            </ul>
        </div>
    )
}

export default RecipeIngredientList;