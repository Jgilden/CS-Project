import UserList from "users/user-list";
import UserFormEditor from "users/user-form-editor";
import RecipeList from "recipes/recipe-list";
import RecipeFormEditor from "recipes/recipe-form-editor";
import IngredientList from "ingredients/ingredient-list";
import IngredientFormEditor from "ingredients/ingredient-form-editor";
import RecipeIngredientList from "./recipeIngredients/recipeIngredient-list";
import RecipeIngredientFormEditor from "./recipeIngredients/recipeIngredient-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM; 
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/users", "/"]} exact={true}>
                    <UserList/>
                </Route>
                <Route path="/users/:id" exact={true}>
                    <UserFormEditor/>
                </Route>
                <Route path="/users/:userId/recipes" exact={true}>
                    <RecipeList/>
                </Route>
                <Route path="/recipes/:id" exact={true}>
                    <RecipeFormEditor/>
                </Route>
                <Route path="/users/:userId/recipes/:recipeId/recipeIngredients" exact={true}>
                    <RecipeIngredientList/>
                </Route>
                <Route path="/recipeIngredients/:id" exact={true}>
                    <RecipeIngredientFormEditor/>
                </Route>
                <Route path="/users/:userId/recipes/:recipeId/ingredients" exact={true}>
                    <IngredientList/>
                </Route>
                <Route path="/ingredients/:id" exact={true}>
                    <IngredientFormEditor/>
                </Route>

            </HashRouter>
        </div>
    );
}

export default App;
