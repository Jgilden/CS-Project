const RECIPEINGREDIENTS_URL = "http://localhost:8080/api/recipeIngredients"
const RECIPES_URL = "http://localhost:8080/api/recipes"

export const findAllRecipeIngredients = () => fetch(RECIPEINGREDIENTS_URL)
    .then(response => response.json())

export const findRecipeIngredientById = (id) => fetch(`${RECIPEINGREDIENTS_URL}/${id}`)
    .then(response => response.json())

export const deleteRecipeIngredient = (id) =>
    fetch(`${RECIPEINGREDIENTS_URL}/${id}`, {
        method: "DELETE"
    })

export const createRecipeIngredient = (recipeIngredient) =>
    fetch(RECIPEINGREDIENTS_URL, {
        method: 'POST',
        body: JSON.stringify(recipeIngredient),
        headers: {'content-type': 'application/json'}
    })
        .then(response => response.json())

export const updateRecipeIngredient = (id, recipeIngredient) =>
    fetch(`${RECIPEINGREDIENTS_URL}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(recipeIngredient),
        headers: {'content-type': 'application/json'}
    })
        .then(response => response.json())

export const findRecipeIngredientByRecipeId = (id) =>
    fetch(`${RECIPES_URL}/${recipeId}/recipeIngredients`).then(response => response.json());

export const createRecipeIngredientForRecipe = (recipeId, recipeIngredient) =>
    fetch(`${RECIPES_URL}/${recipeId}/recipeIngredients`, {
        method: 'POST',
        body: JSON.stringify(recipeIngredient),
        headers: {'content-type': 'application/json'}
    })
        .then(response => response.json())

export default {
    findAllRecipeIngredients,
    findRecipeIngredientById,
    deleteRecipeIngredient,
    createRecipeIngredient,
    updateRecipeIngredient,
    findRecipeIngredientByRecipeId,
    createRecipeIngredientForRecipe
}
