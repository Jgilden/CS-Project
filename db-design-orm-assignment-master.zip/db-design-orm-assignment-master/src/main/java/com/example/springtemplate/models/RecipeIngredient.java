package com.example.springtemplate.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="recipe_ingredient")
@IdClass(RecipeIngredientId.class)
public class RecipeIngredient {
    @Id
    private Integer recipeId;
    @Id
    private Integer ingredientId;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer recipeIngredientId;
    private String unit;
    private Integer quantity;
    private String prepMethod;

    @ManyToOne
    @PrimaryKeyJoinColumn(name = "recipe_id", referencedColumnName = "recipe_id")
    @JsonIgnore
    private Recipe recipe;

    @ManyToOne
    @PrimaryKeyJoinColumn(name = "ingredient_id", referencedColumnName = "ingredient_id")
    @JsonIgnore
    private Ingredient ingredient;

    public Integer getRecipeId() { return recipeId; }
    public void setRecipeId(Integer recipeId) { this.recipeId = recipeId; }

    public Integer getIngredientId() { return ingredientId; }
    public void setIngredientId(Integer ingredientId) { this.ingredientId = ingredientId; }

    public Integer getRecipeIngredientId() { return recipeIngredientId; }
    public void setRecipeIngredientId(Integer recipeIngredientId) { this.recipeIngredientId = recipeIngredientId; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public String getPrepMethod() { return prepMethod; }
    public void setPrepMethod(String prepMethod) { this.prepMethod = prepMethod; }

    public Recipe getRecipe() { return recipe; }
    public void setRecipe(Recipe recipe) { this.recipe = recipe; }

    public Ingredient getIngredient() { return ingredient; }
    public void setIngredient(Ingredient ingredient) { this.ingredient = ingredient; }

    public RecipeIngredient(String unit, Integer quantity, String prep_method, Recipe recipe, Ingredient ingredient) {
        this.unit = unit;
        this.quantity = quantity;
        this.prepMethod = prep_method;
        this.recipe = recipe;
        this.ingredient = ingredient;
    }

    public RecipeIngredient() {}
}