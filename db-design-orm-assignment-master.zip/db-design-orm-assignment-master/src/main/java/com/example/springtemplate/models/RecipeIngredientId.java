package com.example.springtemplate.models;

import java.io.Serializable;

public class RecipeIngredientId implements Serializable {
    private Integer recipeId;
    private Integer ingredientId;

    public Integer getRecipeId() { return recipeId; }
    public void setRecipeId(Integer recipeId) { this.recipeId = recipeId; }

    public Integer getIngredientId() { return ingredientId; }
    public void setIngredientId(Integer ingredientId) { this.ingredientId = ingredientId; }
}
