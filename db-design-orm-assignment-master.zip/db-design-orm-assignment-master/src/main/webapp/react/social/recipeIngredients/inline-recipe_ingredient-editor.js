const {useState, useEffect } = React;
const {Link} = window.ReactRouterDOM;

const InlineRecipe_ingredientEditor = ({recipeIngredient, deleteRecipeIngredient, updateRecipeIngredient}) => {
    const [recipeIngredientCopy, setRecipeIngredientCopy] = useState(recipeIngredient)
    const [editing, setEditing] = useState(false)
    return(
        <div>
            {
                editing &&
                <div className="row">
                    <div className="col">
                        <input
                            className="form-control"
                            value={recipeIngredientCopy.quantity}
                            onChange={(e)=>setRecipeIngredientCopy(recipeIngredientCopy => ({...recipeIngredientCopy, quantity: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={recipeIngredientCopy.unit}
                            onChange={(e)=>setRecipeIngredientCopy(recipeIngredientCopy => ({...recipeIngredientCopy, unit: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={recipeIngredientCopy.prepMethod}
                            onChange={(e)=>setRecipeIngredientCopy(recipeIngredientCopy => ({...recipeIngredientCopy, prepMethod: e.target.value}))}/>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-2x fa-check float-right margin-left-10px"
                           onClick={() => {
                               setEditing(false)
                               updateRecipeIngredient(recipeIngredientCopy.id, recipeIngredientCopy)
                           }}></i>
                        <i className="fas fa-2x fa-undo float-right margin-left-10px"
                           onClick={() => setEditing(false)}></i>
                        <i className="fas fa-2x fa-trash float-right margin-left-10px"
                           onClick={() => deleteRecipeIngredient(recipeIngredient.id)}></i>
                    </div>
                </div>
            }
            {
                !editing &&
                <div className="row">
                    <div className="col">
                        <Link to={`/recipe_ingredients/${recipeIngredientCopy.id}`}>
                            {recipeIngredientCopy.quantity}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/recipe_ingredients/${recipeIngredientCopy.id}`}>
                            {recipeIngredientCopy.unit}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/recipe_ingredients/${recipeIngredientCopy.id}`}>
                            {recipeIngredientCopy.prepMethod}
                        </Link>
                    </div>
                    <div className="col-1">
                        <Link to={`/recipe_ingredients/${recipeIngredientCopy.id}/recipe_ingredients`}>
                            Recipes
                        </Link>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-cog fa-2x float-right"
                           onClick={() => setEditing(true)}></i>
                    </div>
                </div>
            }
        </div>
    )
}

export default InlineRecipe_ingredientEditor;