import recipeIngredientService from "./recipe_ingredient-service"
const {useState, useEffect} = React;
const {useParams, useHistory} = window.ReactRouterDOM;

const Recipe_ingredientFormEditor = () => {
    const {id} = useParams()
    const [recipeIngredient, setUser] = useState({})
    useEffect(() => {
        if(id !== "new") {
            findRecipeIngredientById(id)
        }}, []);
    const findRecipeIngredientById = (id) =>
        recipeIngredientService.findRecipeIngredientById(id)
            .then(recipeIngredient => setRecipeIngredient(recipeIngredient))

    const deleteRecipeIngredient = (id) =>
        recipeIngredientService.deleteRecipeIngredient(id)
            .then(() => history.back())

    const createRecipeIngredient = (recipeIngredient) =>
        recipeIngredientService.createRecipeIngredient(recipeIngredient)
            .then(() => history.back())

    const updateRecipeIngredient = (id, newRecipeIngredient) =>
        recipeIngredientService.updateRecipeIngredient(id, newRecipeIngredient)
            .then(() => history.back())

    return (
        <div>
            <h2>RecipeIngredient Editor</h2>
            <label>Id</label>
            <input value={recipeIngredient.id}/><br/>
            <label>Quantity</label>
            <input
                onChange={(e) =>
                    setRecipeIngredient(recipeIngredient =>
                        ({...recipeIngredient, quantity: e.target.value}))}
                value={recipeIngredient.quantity}/><br/>
            <label>Unit</label>
            <input
                onChange={(e) =>
                    setRecipeIngredient(recipeIngredient =>
                        ({...recipeIngredient, unit: e.target.value}))}
                value={recipeIngredient.unit}/><br/>
            <label>Prep Method</label>
            <input
                onChange={(e) =>
                    setRecipeIngredient(recipeIngredient =>
                        ({...recipeIngredient, prepMethod: e.target.value}))}
                value={recipeIngredient.prepMethod}/><br/>

            <button
                onClick={() => {
                    history.back()}}>
                Cancel
            </button>
            <button
                onClick={() => deleteRecipeIngredient(recipeIngredient.id)}>
                Delete
            </button>
            <button
                onClick={() => createRecipeIngredient(recipeIngredient)}>
                Create
            </button>
            <button
                onClick={() => updateRecipeIngredient(recipeIngredient.id, recipeIngredient)}>
                Save
            </button>
        </div>
    )
}

export default Recipe_ingredientFormEditor