import Recipe_ingredientList from "./recipe_ingredient-list";
import Recipe_ingredientFormEditor from "./recipe_ingredient-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM; 
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/recipe_ingredients", "/"]} exact={true}>
                    <Recipe_ingredientList/>
                </Route>
                <Route path="/recipe_ingredients/:id" exact={true}>
                    <Recipe_ingredientFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
