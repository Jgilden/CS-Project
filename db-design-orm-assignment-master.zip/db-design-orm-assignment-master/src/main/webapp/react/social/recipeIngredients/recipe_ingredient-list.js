const {Link, useHistory} = window.ReactRouterDOM;

import recipeIngredientService, {findAllRecipeIngredients} from "./recipe_ingredient-service"
const { useState, useEffect } = React;

const Recipe_ingredientList = () => {
    const history = useHistory()
    const [recipeIngredients, setRecipeIngredients] = useState([])
    useEffect(() => {
        findAllRecipeIngredients()
    }, [])
    const findAllRecipeIngredients = () =>
        recipeIngredientService.findAllRecipeIngredients()
            .then(recipeIngredients => setRecipeIngredients(recipeIngredients))
    return(
        <div>
            <h2>Recipe Ingredient List</h2>
            <button onClick={() => history.push("/recipe_ingredients/new")}>
                Add RecipeIngredient
            </button>
            <ul className="list-group">
                {
                    recipeIngredients.map(recipeIngredient =>
                        <li key={recipeIngredient.id}>
                            <Link to={`/recipe_ingredients/${recipeIngredient.id}`}>
                                {recipeIngredient.firstName},
                                {recipeIngredient.lastName},
                                {recipeIngredient.username}
                            </Link>
                        </li>)
                }
            </ul>
        </div>
    )
}

export default Recipe_ingredientList;