import IngredientList from "./ingredient-list";
import IngredientFormEditor from "./ingredient-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM; 
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/ingredients", "/"]} exact={true}>
                    <IngredientList/>
                </Route>
                <Route path="/ingredients/:id" exact={true}>
                    <IngredientFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
