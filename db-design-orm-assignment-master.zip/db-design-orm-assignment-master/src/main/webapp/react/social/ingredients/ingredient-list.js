const {Link, useHistory} = window.ReactRouterDOM;

import ingredientService from "./ingredient-service"
const { useState, useEffect } = React;

const IngredientList = () => {
    const history = useHistory()
    const [ingredients, setIngredients] = useState([])
    useEffect(() => {
        findAllIngredients()
    }, [])
    const findAllIngredients = () =>
        ingredientService.findAllIngredients()
            .then(ingredients => setIngredients(ingredients))
    return(
        <div>
            <h2>Ingredient List</h2>
            <button onClick={() => history.push("/ingredients/new")}>
                Add Ingredient
            </button>
            <ul className="list-group">
                {
                    ingredients.map(ingredient =>
                        <li key={ingredient.ingredientId}>
                            <Link to={`/ingredients/${ingredient.ingredientId}`}>
                                {ingredient.ingredient}
                            </Link>
                        </li>)
                }
            </ul>
        </div>
    )
}

export default IngredientList;