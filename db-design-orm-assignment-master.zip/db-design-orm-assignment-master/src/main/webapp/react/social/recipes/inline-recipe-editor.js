const {useState, useEffect } = React;
const {Link} = window.ReactRouterDOM;

const InlineRecipeEditor = ({recipe, deleteRecipe, updateRecipe}) => {
    const [recipeCopy, setRecipeCopy] = useState(recipe)
    const [editing, setEditing] = useState(false)
    return(
        <div>
            {
                editing &&
                <div className="row">
                    <div className="col">
                        <input
                            className="form-control"
                            value={recipeCopy.name}
                            onChange={(e)=>setRecipeCopy(recipeCopy => ({...recipeCopy, name: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={recipeCopy.dietaryRestriction}
                            onChange={(e)=>setRecipeCopy(recipeCopy => ({...recipeCopy, dietaryRestriction: e.target.value}))}/>
                    </div>
                    <div className="col">
                        <input
                            className="form-control"
                            value={recipeCopy.prepTime}
                            onChange={(e)=>setRecipeCopy(recipeCopy => ({...recipeCopy, prepTime: e.target.value}))}/>
                    </div>
                    <div className="col-1">
                        <Link to={`/recipes/${recipeCopy.id}/recipes`}>
                            Recipes
                        </Link>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-2x fa-check float-right margin-left-10px"
                           onClick={() => {
                               setEditing(false)
                               updateRecipe(recipeCopy.id, recipeCopy)
                           }}></i>
                        <i className="fas fa-2x fa-undo float-right margin-left-10px"
                           onClick={() => setEditing(false)}></i>
                        <i className="fas fa-2x fa-trash float-right margin-left-10px"
                           onClick={() => deleteRecipe(recipe.id)}></i>
                    </div>
                </div>
            }
            {
                !editing &&
                <div className="row">
                    <div className="col">
                        <Link to={`/recipes/${recipeCopy.id}`}>
                            {recipeCopy.name}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/recipes/${recipeCopy.id}`}>
                            {recipeCopy.dietaryRestriction}
                        </Link>
                    </div>
                    <div className="col">
                        <Link to={`/recipes/${recipeCopy.id}`}>
                            {recipeCopy.prepTime}
                        </Link>
                    </div>
                    <div className="col-1">
                        <Link to={`/recipes/${recipeCopy.id}/recipes`}>
                            Recipes
                        </Link>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-cog fa-2x float-right"
                           onClick={() => setEditing(true)}></i>
                    </div>
                </div>
            }
        </div>
    )
}

export default InlineRecipeEditor;