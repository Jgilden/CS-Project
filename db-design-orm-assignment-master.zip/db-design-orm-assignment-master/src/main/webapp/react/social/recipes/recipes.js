import RecipeList from "./recipe-list";
import RecipeFormEditor from "./recipe-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM; 
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/recipes", "/"]} exact={true}>
                    <RecipeList/>
                </Route>
                <Route path="/recipes/:id" exact={true}>
                    <RecipeFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
