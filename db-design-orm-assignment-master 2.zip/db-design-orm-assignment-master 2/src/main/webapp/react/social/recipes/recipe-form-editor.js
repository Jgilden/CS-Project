import recipeService from "./recipe-service"
const {useState, useEffect} = React;
const {useParams, useHistory} = window.ReactRouterDOM;

const RecipeFormEditor = () => {
    const {id} = useParams()
    const [recipe, setRecipe] = useState({})
    useEffect(() => {
        if(id !== "new") {
            findRecipeById(id)
        }}, []);
    const findRecipeById = (id) =>
        recipeService.findRecipById(id)
            .then(recipe => setRecipe(recipe))

    const deleteRecipe = (id) => recipeService.deleteRecipe(id)
            .then(() => history.back())

    const createRecipe = (recipe) =>
        recipeService.createRecipe(recipe)
            .then(() => history.back())

    const updateRecipe = (id, newRecipe) =>
        recipeService.updateRecipe(id, newRecipe)
            .then(() => history.back())

    return (
        <div>
            <h2>Recipe Editor</h2>
            <label>Id</label>
            <input value={recipe.id}/><br/>
            <label>Recipe Name</label>
            <input
                onChange={(e) =>
                    setRecipe(recipe =>
                        ({...recipe, name: e.target.value}))}
                value={recipe.name}/><br/>
            <label>Dietary Restriction</label>
            <input
                onChange={(e) =>
                    setRecipe(recipe =>
                        ({...recipe, dietaryRestriction: e.target.value}))}
                value={recipe.dietaryRestriction}/><br/>
            <label>Prep Time</label>
            <input
                onChange={(e) =>
                    setRecipe(recipe =>
                        ({...recipe, prepTime: e.target.value}))}
                value={recipe.prepTime}/><br/>
            <label>Cook Time</label>
            <input
                onChange={(e) =>
                    setRecipe(recipe =>
                        ({...recipe, cookTime: e.target.value}))}
                value={recipe.cookTime}/><br/>
            <label>Serving Size</label>
            <input
                onChange={(e) =>
                    setRecipe(recipe =>
                        ({...recipe, servingSize: e.target.value}))}
                value={recipe.servingSize}/><br/>
            <label>Instructions</label>
            <input
                onChange={(e) =>
                    setRecipe(recipe =>
                        ({...recipe, instructions: e.target.value}))}
                value={recipe.instructions}/><br/>

            <button
                onClick={() => {
                    history.back()}}>
                Cancel
            </button>
            <button
                onClick={() => deleteRecipe(recipe.id)}>
                Delete
            </button>
            <button
                onClick={() => createRecipe(recipe)}>
                Create
            </button>
            <button
                onClick={() => updateRecipe(recipe.id, recipe)}>
                Save
            </button>
        </div>
    )
}

export default RecipeFormEditor