// const {Link, useHistory} = window.ReactRouterDOM;
//
// import recipeService from "./recipe-service"
// const { useState, useEffect } = React;
//
// const RecipeList = () => {
//     const history = useHistory()
//     const [recipes, setRecipes] = useState([])
//     useEffect(() => {
//         findAllRecipes()
//     }, [])
//     const findAllRecipes = () =>
//         recipeService.findAllRecipes()
//             .then(recipes => setRecipes(recipes))
//     return(
//         <div>
//             <h2>Recipe List</h2>
//             <button onClick={() => history.push("/recipes/new")}>
//                 Add Recipe
//             </button>
//             <ul className="list-group">
//                 {
//                     recipes.map(recipe =>
//                         <li key={recipe.recipeId}>
//                             <Link to={`/recipes/${recipe.recipeId}`}>
//                                 {recipe.recipeName}
//                             </Link>
//                         </li>)
//                 }
//             </ul>
//         </div>
//     )
// }
//
// export default RecipeList;







const {Link, useHistory} = window.ReactRouterDOM;

import recipeService from "./recipe-service"
import userService, {findRecipeByUserId, findUserById} from "../users/user-service"
const { useState, useEffect } = React;
const {useParams} = window.ReactRouterDOM;

const RecipeList = () => {
    const [recipes, setRecipes] = useState([])
    const[newRecipe, setNewRecipe] = useState([])
    const {userId} = useParams()
    useEffect(() => {findRecipeByUserId(userId)}, [])
    const createRecipeForUser = (recipe) =>
        recipeService.createRecipeForCourse(userId, recipe)
            .then(recipe => {
                setNewRecipe({recipeName:''})
                setRecipes(recipes => ([...recipes, recipe]))
            })

    const updateRecipe = (id, newRecipe) =>
        recipeService.updateRecipe(id, newRecipe)
            .then(recipes => setRecipes(recipes => (recipes.map(recipe => recipe.id === id ? newRecipe : recipe))))
    const findRecipeByUserId = (id) =>
        recipeService.findRecipeByUserId(userId)
            .then(recipes => setRecipes(recipes))
    const deleteRecipe = (id) =>
        recipeService.deleteRecipe(id)
            .then(recipes => setRecipes(recipes => recipes.filter(recipe => recipe.id !== id)))
    return(
        <div>
            <h2>Recipe List</h2>
            <button onClick={() => history.push("/recipes/new")}>
                Add Recipe
            </button>
            <ul className="list-group">
                {
                    recipes.map(recipe =>
                        <li key={recipe.id}>
                            <Link to={`/users/${userId}/recipes/${recipe.id}`}>
                                {recipe.recipeName}
                            </Link>
                        </li>)
                }
            </ul>
        </div>
    )
}

export default RecipeList;