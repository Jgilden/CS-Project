const INGREDIENTS_URL = "http://localhost:8080/api/ingredients"

export const findAllIngredients = () => fetch(INGREDIENTS_URL)
    .then(response => response.json())

export const findIngredientById = (id) => fetch(`${INGREDIENTS_URL}/${id}`)
    .then(response => response.json())

export const deleteIngredient = (id) =>
    fetch(`${INGREDIENTS_URL}/${id}`, {
        method: "DELETE"
    })

export const createIngredient = (ingredient) =>
    fetch(INGREDIENTS_URL, {
        method: 'POST',
        body: JSON.stringify(ingredient),
        headers: {'content-type': 'application/json'}
    })
        .then(response => response.json())

export const updateIngredient = (id, ingredient) =>
    fetch(`${INGREDIENTS_URL}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(ingredient),
        headers: {'content-type': 'application/json'}
    })
        .then(response => response.json())

export default {
    findAllIngredients,
    findIngredientById,
    deleteIngredient,
    createIngredient,
    updateIngredient
}
