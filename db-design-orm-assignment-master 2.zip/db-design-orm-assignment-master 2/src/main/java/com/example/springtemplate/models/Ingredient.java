package com.example.springtemplate.models;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="ingredients")
public class Ingredient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer ingredientId;
    private String ingredient;

    @OneToMany(mappedBy = "ingredient")
    private List<RecipeIngredient> recipes;

    public Integer getIngredientId() { return ingredientId; }
    public void setIngredientId(Integer ingredientId) { this.ingredientId = ingredientId; }

    public String getIngredient() { return ingredient; }
    public void setIngredient(String ingredient) { this.ingredient = ingredient; }

    public List<RecipeIngredient> getRecipes() { return recipes; }
    public void setRecipes(List<RecipeIngredient> recipes) { this.recipes = recipes; }

    public Ingredient(String ingredient) {
        this.ingredient = ingredient;
    }

    public Ingredient() {}
}