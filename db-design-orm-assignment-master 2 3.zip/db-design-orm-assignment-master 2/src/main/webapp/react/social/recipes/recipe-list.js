const {Link, useHistory} = window.ReactRouterDOM;

import recipeService from "./recipe-service"
import userService, {findRecipeByUserId, findUserById} from "../users/user-service"
const { useState, useEffect } = React;

const RecipeList = () => {
    const {userId} = useParams();
    const [recipes, setRecipes] = useState([])
    const {user, setUser} = useState([])
    const history = useHistory()
    useEffect(() => {findRecipeByUserId(userId)}, []);
    useEffect(() => {findUserById(userId)}, []);
    // useEffect(() => {findAllRecipes()}, [])
    // const findAllRecipes = () =>
    //     recipeService.findAllRecipes()
    //         .then(recipes => {
    //             setRecipes(recipes)})
    const findRecipeByUserId = (userId) =>
        recipeService.findRecipeByUserId(userId).then(recipes => setUser(user));
    const findUserbyId = (id) =>
        userService.findUserById(id).then(user => setUser(user));
    return(
        <div>
            <h2>Recipe List</h2>
            <button onClick={() => history.push("/recipes/new")}>
                Add Recipe
            </button>
            <ul className="list-group">
                {
                    recipes.map(recipe =>
                        <li key={recipe.recipeId}>
                            <Link to={`/recipes/${recipe.recipeId}`}>
                                {recipe.recipeName}
                            </Link>
                        </li>)
                }
            </ul>
        </div>
    )
}

export default RecipeList;