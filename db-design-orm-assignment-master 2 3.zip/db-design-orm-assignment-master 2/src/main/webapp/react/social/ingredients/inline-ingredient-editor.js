const {useState, useEffect } = React;
const {Link} = window.ReactRouterDOM;

const InlineIngredientEditor = ({ingredient, deleteIngredient, updateIngredient}) => {
    const [ingredientCopy, setIngredientCopy] = useState(ingredient)
    const [editing, setEditing] = useState(false)
    return(
        <div>
            {
                editing &&
                <div className="row">
                    <div className="col">
                        <input
                            className="form-control"
                            value={ingredientCopy.ingredient}
                            onChange={(e)=>setIngredientCopy(ingredientCopy => ({...ingredientCopy, ingredient: e.target.value}))}/>
                    </div>
                    <div className="col-1">
                        <Link to={`/ingredients/${ingredientCopy.id}/ingredients`}>
                            Ingredients
                        </Link>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-2x fa-check float-right margin-left-10px"
                           onClick={() => {
                               setEditing(false)
                               updateIngredient(ingredientCopy.id, ingredientCopy)
                           }}></i>
                        <i className="fas fa-2x fa-undo float-right margin-left-10px"
                           onClick={() => setEditing(false)}></i>
                        <i className="fas fa-2x fa-trash float-right margin-left-10px"
                           onClick={() => deleteIngredient(ingredient.id)}></i>
                    </div>
                </div>
            }
            {
                !editing &&
                <div className="row">
                    <div className="col">
                        <Link to={`/ingredients/${ingredientCopy.id}`}>
                            {ingredientCopy.ingredient}
                        </Link>
                    </div>
                    <div className="col-1">
                        <Link to={`/ingredients/${ingredientCopy.id}/ingredients`}>
                            Ingredients
                        </Link>
                    </div>
                    <div className="col-2">
                        <i className="fas fa-cog fa-2x float-right"
                           onClick={() => setEditing(true)}></i>
                    </div>
                </div>
            }
        </div>
    )
}

export default InlineIngredientEditor;