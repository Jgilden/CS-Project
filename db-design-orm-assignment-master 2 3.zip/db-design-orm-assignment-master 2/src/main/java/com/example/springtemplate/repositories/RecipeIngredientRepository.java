package com.example.springtemplate.repositories;

import com.example.springtemplate.models.RecipeIngredient;
import com.example.springtemplate.models.RecipeIngredientId;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RecipeIngredientRepository extends CrudRepository<RecipeIngredient, RecipeIngredientId> {
    @Query(value = "SELECT * FROM recipe_ingredient",
            nativeQuery = true)
    public List<RecipeIngredient> findAllRecipeIngredients();
    @Query(value = "SELECT * FROM recipe_ingredient WHERE recipe_ingredient_id=:recipeIngredientId",
            nativeQuery = true)
    public RecipeIngredient findRecipeIngredientById(@Param("recipeIngredientId") Integer recipeIngredientId);
}
