import ingredientService from "./ingredient-service"
const {useState, useEffect} = React;
const {useParams, useHistory} = window.ReactRouterDOM;

const IngredientFormEditor = () => {
    const {id} = useParams()
    const [ingredient, setIngredient] = useState({})
    useEffect(() => {
        if(id !== "new") {
            findIngredientById(id)
        }}, []);
    const findIngredientById = (id) =>
        ingredientService.findIngredientById(id)
            .then(ingredient => setIngredient(ingredient))

    const deleteIngredient = (id) => ingredientService.deleteIngredient(id)
            .then(() => history.back())

    const createIngredient = (ingredient) =>
        ingredientService.createIngredient(ingredient)
            .then(() => history.back())

    const updateIngredient = (id, newIngredient) =>
        ingredientService.updateIngredient(id, newIngredient)
            .then(() => history.back())

    return (
        <div>
            <h2>Ingredient Editor</h2>
            <label>Id</label>
            <input value={ingredient.ingredientId}/><br/>
            <label>Ingredient</label>
            <input
                onChange={(e) =>
                    setIngredient(ingredient =>
                        ({...ingredient, ingredient: e.target.value}))}
                value={ingredient.ingredient}/><br/>

            <button
                onClick={() => {
                    history.back()}}>
                Cancel
            </button>
            <button
                onClick={() => deleteIngredient(ingredient.ingredientId)}>
                Delete
            </button>
            <button
                onClick={() => createIngredient(ingredient)}>
                Create
            </button>
            <button
                onClick={() => updateIngredient(ingredient.ingredientId, ingredient)}>
                Save
            </button>
        </div>
    )
}

export default IngredientFormEditor