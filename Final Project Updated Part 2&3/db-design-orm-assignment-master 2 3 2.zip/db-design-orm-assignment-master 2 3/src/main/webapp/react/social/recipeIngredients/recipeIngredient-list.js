const {Link, useHistory} = window.ReactRouterDOM;

import ingredientService from "./recipeIngredient-service"
const { useState, useEffect } = React;

const RecipeIngredientList = () => {
    const history = useHistory()
    const [recipeIngredients, setRecipeIngredients] = useState([])
    useEffect(() => {
        findAllRecipeIngredients()
    }, [])
    const findAllRecipeIngredients = () =>
        recipeIngredientService.findAllRecipeIngredients()
            .then(recipeIngredients => setRecipeIngredients(recipeIngredients))
    return(
        <div>
            <h2>Recipe Ingredient List</h2>
            <button onClick={() => history.push("/recipeIngredients/new")}>
                Add Recipe Ingredient
            </button>
            <ul className="list-group">
                {
                    recipeIngredients.map(recipeIngredient =>
                        <li key={recipeIngredient.id}>
                            <Link to={`/recipeIngredients/${recipeIngredient.id}`}>
                                {recipeIngredient.id}
                            </Link>
                        </li>)
                }
            </ul>
        </div>
    )
}

export default RecipeIngredientList;