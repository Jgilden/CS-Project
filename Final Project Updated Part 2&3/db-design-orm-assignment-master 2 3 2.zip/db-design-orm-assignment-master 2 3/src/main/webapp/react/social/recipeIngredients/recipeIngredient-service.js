const RECIPEINGREDIENTS_URL = "http://localhost:8080/api/recipeIngredients"

export const findAllRecipeIngredients = () => fetch(RECIPEINGREDIENTS_URL)
    .then(response => response.json())

export const findRecipeIngredientById = (id) => fetch(`${RECIPEINGREDIENTS_URL}/${id}`)
    .then(response => response.json())

export const deleteRecipeIngredient = (id) =>
    fetch(`${RECIPEINGREDIENTS_URL}/${id}`, {
        method: "DELETE"
    })

export const createRecipeIngredient = (recipeIngredient) =>
    fetch(RECIPEINGREDIENTS_URL, {
        method: 'POST',
        body: JSON.stringify(recipeIngredient),
        headers: {'content-type': 'application/json'}
    })
        .then(response => response.json())

export const updateRecipeIngredient = (id, recipeIngredient) =>
    fetch(`${RECIPEINGREDIENTS_URL}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(recipeIngredient),
        headers: {'content-type': 'application/json'}
    })
        .then(response => response.json())

export default {
    findAllRecipeIngredients,
    findRecipeIngredientById,
    deleteRecipeIngredient,
    createRecipeIngredient,
    updateRecipeIngredient
}
