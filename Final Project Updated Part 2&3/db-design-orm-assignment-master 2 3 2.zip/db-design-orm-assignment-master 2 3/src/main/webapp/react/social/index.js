import UserList from "./users/user-list";
import UserFormEditor from "./users/user-form-editor";
import RecipeList from "./recipes/recipe-list";
import RecipeFormEditor from "./recipes/recipe-form-editor";
import RecipeIngredientList from "./recipeIngredients/recipeIngredient-list";
import RecipeIngredientFormEditor from "./recipeIngredients/recipeIngredient-form-editor";


const {HashRouter, Link, Route} = window.ReactRouterDOM;

const App = () => {
    console.log(window.ReactRouterDOM)
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/users", "/"]} exact={true}>
                    <UserList/>
                </Route>
                <Route path="/users/:id" exact={true}>
                    <UserFormEditor/>
                </Route>
                <Route path={["/recipes", "/"]} exact={true}>
                    <RecipeList/>
                </Route>
                <Route path="/recipes/:id" exact={true}>
                    <RecipeFormEditor/>
                </Route>
                {/*<Route path="/users/:userId/recipes" exact={true}>*/}
                {/*    <RecipeList/>*/}
                {/*</Route>*/}
                {/*<Route path="/recipes/:recipeId" exact={true}>*/}
                {/*    <RecipeFormEditor/>*/}
                {/*</Route>*/}
                <Route path={["/recipeIngredients", "/"]} exact={true}>
                    <RecipeIngredientList/>
                </Route>
                <Route path="/recipeIngredients/:id" exact={true}>
                    <RecipeIngredientFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;