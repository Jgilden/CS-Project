package com.example.springtemplate.daos;

import com.example.springtemplate.models.Recipe;
import com.example.springtemplate.models.User;
import com.example.springtemplate.repositories.RecipeRepository;
import com.example.springtemplate.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

public class UserRecipeOrmDao {
    @Autowired
    UserRepository userRepository;
    @Autowired
    RecipeRepository recipeRepository;

    @PostMapping("/api/addRecipe/{recipeId}/toUser/{userId}")
    public User addRecipeToUser(
            @PathVariable("recipeId") Integer recipeId,
            @PathVariable("userId") Integer userId){
        User user = userRepository.findUserById(userId);
        Recipe recipe = recipeRepository.findRecipeById(recipeId);
        user.getRecipes().add(recipe);
        recipe.setUser(user);
        recipeRepository.save(recipe);
        return user;
    }

    @DeleteMapping("/api/removeRecipe/{recipeId}/fromUser/{userId}")
    public User removeRecipeFromUser(
            @PathVariable("recipeId") Integer recipeId,
            @PathVariable("userId") Integer userId){
        User user = userRepository.findUserById(userId);
        Recipe recipe = recipeRepository.findRecipeById(recipeId);
        user.getRecipes().remove(recipe);
        recipe.setUser(null);
        recipeRepository.save(recipe);
        return user;
    }

    @PutMapping("/api/user/{userId}/created/{recipeId}")
    public void createdRecipes(
            @PathVariable("userId") int userId,
            @PathVariable("recipeId") int recipeId){
        User user = userRepository.findUserById(userId);
        Recipe recipe = recipeRepository.findRecipeById(recipeId);
        recipe.setUser(user);
        recipeRepository.save(recipe);
    }

    @GetMapping("/api/user/{userId}/created")
    public List<Recipe> findUsersRecipes(
            @PathVariable("userId") int userId){
        User user = userRepository.findUserById(userId);
        return user.getRecipes();
    }

    @GetMapping("/api/recipe/{recipeId}/user")
    public User findRecipesUser(
            @PathVariable("recipeId") int recipeId){
        Recipe recipe = recipeRepository.findRecipeById(recipeId);
        return recipe.getUser();
    }
}
