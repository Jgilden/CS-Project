package com.example.springtemplate.models;

public enum DietaryRestriction {
    NoRestriction,
    NutFree,
    Pescatarian,
    Vegan,
    Vegetarian
}

